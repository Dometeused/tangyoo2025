'use client';
import { useRef, useEffect, useState } from "react";
import mojs from "@mojs/core";
import "./romantic-love.css";

export default function RomanticLove({
  message = "❤️ ยินดีด้วย! วันนี้เป็นวันพิเศษที่มีความหมายต่อหัวใจของเรา",
}) {
  // SVG element refs
  const refs = {
    moContainer: useRef(null),
    I: useRef(null), L: useRef(null), O: useRef(null), V: useRef(null), E: useRef(null),
    Y: useRef(null), O2: useRef(null), U: useRef(null),
    lineLeft: useRef(null), lineRight: useRef(null),
    blup: useRef(null), blop: useRef(null)
  };

  const [showMsg, setShowMsg] = useState(false);

  useEffect(() => {
    // Heart shape (mo.js custom)
    class Heart extends mojs.CustomShape {
      getShape() {
        return '<path d="M50,88.9C25.5,78.2,0.5,54.4,3.8,31.1S41.3,1.8,50,29.9c8.7-28.2,42.8-22.2,46.2,1.2S74.5,78.2,50,88.9z"/>';
      }
      getLength () { return 200; }
    }
    mojs.addShape('heart', Heart);

    // Query (useRef)
    const el = {
      container: refs.moContainer.current,
      I: refs.I.current, L: refs.L.current, O: refs.O.current, V: refs.V.current,
      E: refs.E.current, Y: refs.Y.current, O2: refs.O2.current, U: refs.U.current,
      lineLeft: refs.lineLeft.current, lineRight: refs.lineRight.current,
      blup: refs.blup.current, blop: refs.blop.current
    };

    const easingHeart = mojs.easing.path('M0,100C2.9,86.7,33.6-7.3,46-7.3s15.2,22.7,26,22.7S89,0,100,0');
    const colTxt = "#763c8c", colHeart = "#fa4843";

    // Helper burst
    const crtBoom = (delay = 0, x = 0, rd = 46) => {
      return [
        new mojs.Shape({
          shape: 'circle',
          fill: 'none',
          stroke: colTxt,
          strokeWidth: { 5: 0 },
          radius: { [rd]: [rd + 20] },
          easing: 'quint.out',
          duration: 500 / 3,
          parent: el.container,
          delay,
          x,
        }),
        new mojs.Burst({
          radius: { [rd + 15]: 110 },
          angle: 'rand(60, 180)',
          count: 3,
          timeline: { delay },
          parent: el.container,
          x,
          children: {
            radius: [5, 3, 7],
            fill: colTxt,
            scale: { 1: 0, easing: 'quad.in' },
            pathScale: [0.8, null],
            degreeShift: ['rand(13, 60)', null],
            duration: 1000 / 3,
            easing: 'quint.out'
          }
        })
      ];
    };

    // Timeline like original
    const move = 1000, boom = 200, easing = 'sin.inOut', delta = 150;
    const opts = { duration: move, easing, opacity: 1 };

    // main mo.js timeline
    const loveTl = new mojs.Timeline();

    // 1. Lines, I, L, O, V, E, Y, O2, U
    loveTl.add(
      // Animation for all letters and lines (condensed for brevity)
      ...[
        new mojs.Html({ ...opts, el: el.lineLeft, x: { 0: 52 } }).then({ duration: boom + move, x: { to: 52 + 54 } }).then({ duration: boom + move, x: { to: 52 + 54 + 60 } }).then({ duration: 150, x: { to: 52 + 54 + 60 + 10 } }).then({ duration: 300 }).then({ duration: 350, x: { to: 0 }, easing: 'sin.out' }),
        new mojs.Html({ ...opts, el: el.lineRight, x: { 0: -52 } }).then({ duration: boom + move, x: { to: -52 - 54 } }).then({ duration: boom + move, x: { to: -52 - 54 - 60 } }).then({ duration: 150, x: { to: -52 - 54 - 60 - 10 } }).then({ duration: 300 }).then({ duration: 350, x: { to: 0 }, easing: 'sin.out' }),
        new mojs.Html({ ...opts, el: el.I, x: { 0: 34 } }).then({ duration: boom, x: { to: 34 + 19 } }).then({ duration: move, x: { to: 34 + 19 + 40 } }).then({ duration: boom, x: { to: 34 + 19 + 40 + 30 } }).then({ duration: move, x: { to: 34 + 19 + 40 + 30 + 30 } }),
        new mojs.Html({ ...opts, el: el.L, x: { 0: 15 } }),
        new mojs.Html({ ...opts, el: el.O, x: { 0: 11 } }),
        new mojs.Html({ ...opts, el: el.V, x: { 0: 3 } }),
        new mojs.Html({ ...opts, el: el.E, x: { 0: -3 } }),
        new mojs.Html({ ...opts, el: el.Y, x: { 0: -20 } }).then({ duration: boom, x: { to: -20 - 33 } }).then({ duration: move, x: { to: -20 - 33 - 24 } }),
        new mojs.Html({ ...opts, el: el.O2, x: { 0: -27 } }).then({ duration: boom, x: { to: -27 - 27 } }).then({ duration: move, x: { to: -27 - 27 - 30 } }),
        new mojs.Html({ ...opts, el: el.U, x: { 0: -32 } }).then({ duration: boom, x: { to: -32 - 21 } }).then({ duration: move, x: { to: -32 - 21 - 36 } }).then({ duration: boom, x: { to: -32 - 21 - 36 - 31 } }).then({ duration: move, x: { to: -32 - 21 - 36 - 31 - 27 } }),
      ],
      // Heart
      new mojs.Shape({
        parent: el.container,
        shape: 'heart',
        delay: move,
        fill: colHeart,
        x: -64,
        scale: { 0: 0.95, easing: easingHeart },
        duration: 500
      }).then({ x: { to: -62, easing }, scale: { to: 0.65, easing }, duration: boom + move - 500 })
        .then({ duration: boom - 50, x: { to: -62 + 48 }, scale: { to: 0.90 }, easing: 'sin.in' })
        .then({ duration: 125, scale: { to: 0.8 }, easing: 'sin.out' })
        .then({ duration: 125, scale: { to: 0.85 }, easing: 'sin.out' })
        .then({ duration: move - 200, scale: { to: 0.45 }, easing })
        .then({ delay: -75, duration: 150, x: { to: 0 }, scale: { to: 0.90 }, easing: 'sin.in' })
        .then({ duration: 125, scale: { to: 0.8 }, easing: 'sin.out' })
        .then({ duration: 125, scale: { to: 0.85 }, easing: 'sin.out' })
        .then({ duration: 125 })
        .then({ duration: 350, scale: { to: 0 }, easing: 'sin.out', onComplete: () => setShowMsg(true) }),
      // Bursts
      ...crtBoom(move, -64, 46),
      ...crtBoom(move * 2 + boom, 18, 34),
      ...crtBoom(move * 3 + boom * 2 - delta, -64, 34),
      ...crtBoom(move * 3 + boom * 2, 45, 34)
    );

    // Set opacity letters before start
    [el.I, el.L, el.O, el.V, el.E, el.Y, el.O2, el.U].forEach(node => {
      if (node) node.style.opacity = 1;
    });

    // loop + show message after 1st
    loveTl.play();
    let loopId = setTimeout(() => setShowMsg(true), 4300);
    let interval = setInterval(() => {
      setShowMsg(false);
      loveTl.replay();
      loopId = setTimeout(() => setShowMsg(true), 4300);
    }, 4300);

    // cleanup
    return () => {
      clearInterval(interval);
      clearTimeout(loopId);
      loveTl.stop();
    };
    // eslint-disable-next-line
  }, []);

  return (
    <div className="romantic-container">
      {/* เสียง */}
      <audio ref={refs.blup} className="blup" style={{ display: "none" }}>
        <source src="https://www.freesound.org/data/previews/265/265115_4373976-lq.mp3" type="audio/ogg" />
      </audio>
      <audio ref={refs.blop} className="blop" style={{ display: "none" }}>
        <source src="https://www.freesound.org/data/previews/265/265115_4373976-lq.mp3" type="audio/ogg" />
      </audio>

      {/* SVG */}
      <div className="container">
        <svg className="svg-container" viewBox="0 0 500 200">
          <line ref={refs.lineLeft} className="line line--left" x1="10" y1="17" x2="10" y2="183" />
          <line ref={refs.lineRight} className="line line--rght" x1="490" y1="17" x2="490" y2="183" />
          <g>
            <path ref={refs.I} className="lttr lttr--I" d="M42.2,73.9h11.4v52.1H42.2V73.9z"></path>
            <path ref={refs.L} className="lttr lttr--L" d="M85.1,73.9h11.4v42.1h22.8v10H85.1V73.9z"></path>
            <path ref={refs.O} className="lttr lttr--O" d="M123.9,100c0-15.2,11.7-26.9,27.2-26.9s27.2,11.7,27.2,26.9s-11.7,26.9-27.2,26.9S123.9,115.2,123.9,100zM166.9,100c0-9.2-6.8-16.5-15.8-16.5c-9,0-15.8,7.3-15.8,16.5s6.8,16.5,15.8,16.5C160.1,116.5,166.9,109.2,166.9,100z"></path>
            <path ref={refs.V} className="lttr lttr--V" d="M180.7,73.9H193l8.4,22.9c1.7,4.7,3.5,9.5,5,14.2h0.1c1.7-4.8,3.4-9.4,5.2-14.3l8.6-22.8h11.7l-19.9,52.1h-11.5L180.7,73.9z"></path>
            <path ref={refs.E} className="lttr lttr--E" d="M239.1,73.9h32.2v10h-20.7v10.2h17.9v9.5h-17.9v12.4H272v10h-33V73.9z"></path>
            <path ref={refs.Y} className="lttr lttr--Y" d="M315.8,102.5l-20.1-28.6H309l6.3,9.4c2,3,4.2,6.4,6.3,9.6h0.1c2-3.2,4.1-6.4,6.3-9.6l6.3-9.4h12.9l-19.9,28.5v23.6h-11.4V102.5z"></path>
            <path ref={refs.O2} className="lttr lttr--O2" d="M348.8,100c0-15.2,11.7-26.9,27.2-26.9c15.5,0,27.2,11.7,27.2,26.9s-11.7,26.9-27.2,26.9C360.5,126.9,348.8,115.2,348.8,100z M391.8,100c0-9.2-6.8-16.5-15.8-16.5c-9,0-15.8,7.3-15.8,16.5s6.8,16.5,15.8,16.5C385,116.5,391.8,109.2,391.8,100z"></path>
            <path ref={refs.U} className="lttr lttr--U" d="M412.4,101.1V73.9h11.4v26.7c0,10.9,2.4,15.9,11.5,15.9c8.4,0,11.4-4.6,11.4-15.8V73.9h11v26.9c0,7.8-1.1,13.5-4,17.7c-3.7,5.3-10.4,8.4-18.7,8.4c-8.4,0-15.1-3.1-18.8-8.5C413.4,114.2,412.4,108.5,412.4,101.1z"></path>
          </g>
        </svg>
        <div ref={refs.moContainer} className="mo-container"></div>
        {showMsg && (
          <div className="congrats-msg">
            <span>{message}</span>
          </div>
        )}
      </div>
    </div>
  );
}
